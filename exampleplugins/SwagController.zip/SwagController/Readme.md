# SwagController
Simple example of how to create a controller from a plugin

# How to use
* Install and activate the plugin in the plugin manager
* call http://your-shop.com/SwagControllerTest
* Surf to product listing