<?php

require_once __DIR__ . '/../../../../autoload.php';

$enlightLoader = new Enlight_Loader();

$enlightLoader->registerNamespace(
    'SwagMd5Reversed',
    __DIR__ . '/../'
);
