<?php

namespace SwagCustomListingTheme;

use Shopware\Components\Plugin;

class SwagCustomListingTheme extends Plugin
{

}
